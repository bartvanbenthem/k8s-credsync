// +build tools

package kail

import (
	_ "github.com/goreleaser/godownloader"
)
